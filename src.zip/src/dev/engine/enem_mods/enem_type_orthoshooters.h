// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

	// Include this code after `enem_type_lineal.h` so they move!
	
	if (ORTHOSHOOTERS_FREQ == 1) {
		rda = en_an_state [enit];
		simple_coco_shoot ();
	} 
