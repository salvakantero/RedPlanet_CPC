// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

#define SFX_START 				0   // void
#define SFX_BREAKABLE_HIT 		1   // void
#define SFX_BREAKABLE_BREAK 	2   // void
#define SFX_PUSH_BOX 			3   // void
#define SFX_OPEN_LOCK 			3
#define SFX_SHOOT 				4
#define SFX_OBJECT_GET 			5
#define SFX_KILL_ENEMY_STEP 	6
#define SFX_KILL_ENEMY_SHOOT	6
#define SFX_HIT_ENEMY 			7
#define SFX_ONE_OBJECT_GET		8   // void
#define SFX_ONE_OBJECT_WRONG 	9   // void
#define SFX_KEY_GET 			10
#define SFX_REFILL_GET 			11
#define SFX_JUMP 				12
#define SFX_SPIKES 				13
#define SFX_ENEMY_HIT 			14
