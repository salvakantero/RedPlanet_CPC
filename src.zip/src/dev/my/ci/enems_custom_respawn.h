// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// deactivate RESPAWN_ON_ENTER and write your own routine here!

