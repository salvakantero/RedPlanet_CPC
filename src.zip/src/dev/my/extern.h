// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// External custom code to be run from a script

void do_extern_action (unsigned char n) {
	// Add custom code here.	
}
